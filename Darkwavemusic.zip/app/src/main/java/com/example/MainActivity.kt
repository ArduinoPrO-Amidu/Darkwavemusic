package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.ui.DarkWaveApp
import com.example.ui.theme.DarkWaveTheme
import com.example.ui.viewmodel.MusicPlayerViewModel

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: MusicPlayerViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val factory = MusicPlayerViewModel.provideFactory(application)
        viewModel = ViewModelProvider(this, factory)[MusicPlayerViewModel::class.java]

        setContent {
            DarkWaveTheme {
                DarkWaveApp(viewModel = viewModel)
            }
        }
    }
}
