package com.example.data.repository

import com.example.data.local.db.DarkWaveDatabase
import com.example.data.local.db.FavoriteSongEntity
import com.example.data.local.db.PlaylistEntity
import com.example.data.local.db.PlaylistSongCrossRef
import com.example.data.local.db.RecentlyPlayedEntity
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.MusicFolder
import com.example.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withContext

data class PlaylistWithSongs(
    val playlist: PlaylistEntity,
    val songs: List<Song>
)

class MusicRepository(
    private val scanner: MediaStoreScanner,
    private val database: DarkWaveDatabase
) {
    private val dao = database.musicDao()
    private val repoScope = CoroutineScope(Dispatchers.IO)

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    val albums: Flow<List<Album>> = _songs.map { scanner.extractAlbums(it) }
    val artists: Flow<List<Artist>> = _songs.map { scanner.extractArtists(it) }
    val folders: Flow<List<MusicFolder>> = _songs.map { scanner.extractFolders(it) }

    val allPlaylists: Flow<List<PlaylistEntity>> = dao.getAllPlaylists()
    val favoriteSongIds: Flow<List<Long>> = dao.getAllFavoriteSongIds()

    val favoriteSongs: Flow<List<Song>> = combine(_songs, favoriteSongIds) { allSongs, favIds ->
        val songMap = allSongs.associateBy { it.id }
        favIds.mapNotNull { songMap[it] }
    }.flowOn(Dispatchers.Default)

    val recentlyPlayedSongs: Flow<List<Song>> = combine(
        _songs,
        dao.getRecentlyPlayedSongIds(30)
    ) { allSongs, recentIds ->
        val songMap = allSongs.associateBy { it.id }
        recentIds.mapNotNull { songMap[it] }
    }.flowOn(Dispatchers.Default)

    suspend fun refreshMusicLibrary(): List<Song> {
        _isScanning.value = true
        return try {
            val scanned = scanner.scanMusicFiles()
            _songs.value = scanned
            scanned
        } finally {
            _isScanning.value = false
        }
    }

    // --- Playlists ---
    suspend fun createPlaylist(name: String): Long = withContext(Dispatchers.IO) {
        dao.insertPlaylist(PlaylistEntity(name = name.trim()))
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) = withContext(Dispatchers.IO) {
        dao.updatePlaylistName(playlistId, newName.trim())
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        dao.deletePlaylistSongs(playlistId)
        dao.deletePlaylist(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        dao.addSongToPlaylist(PlaylistSongCrossRef(playlistId = playlistId, songId = songId))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        dao.removeSongFromPlaylist(playlistId, songId)
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<Song>> {
        return combine(_songs, dao.getSongIdsForPlaylist(playlistId)) { allSongs, ids ->
            val songMap = allSongs.associateBy { it.id }
            ids.mapNotNull { songMap[it] }
        }.flowOn(Dispatchers.Default)
    }

    // --- Favorites ---
    suspend fun toggleFavorite(songId: Long, isFav: Boolean) = withContext(Dispatchers.IO) {
        if (isFav) {
            dao.removeFavorite(songId)
        } else {
            dao.addFavorite(FavoriteSongEntity(songId = songId))
        }
    }

    fun isFavorite(songId: Long): Flow<Boolean> = dao.isFavorite(songId)

    // --- History ---
    suspend fun recordRecentlyPlayed(songId: Long) = withContext(Dispatchers.IO) {
        dao.recordRecentlyPlayed(RecentlyPlayedEntity(songId = songId, playedAt = System.currentTimeMillis()))
    }
}
