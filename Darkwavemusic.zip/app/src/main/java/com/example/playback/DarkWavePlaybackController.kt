package com.example.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class DarkWavePlaybackController(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onSongPlayed: (Song) -> Unit = {}
) {
    private var mediaController: MediaController? = null
    private var positionTickerJob: Job? = null

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(-1)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
            if (isPlaying) {
                startPositionTicker()
            } else {
                stopPositionTicker()
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val controller = mediaController ?: return
            val index = controller.currentMediaItemIndex
            _currentIndex.value = index

            val currentQueue = _queue.value
            if (index in currentQueue.indices) {
                val song = currentQueue[index]
                _currentSong.value = song
                _durationMs.value = if (song.durationMs > 0) song.durationMs else controller.duration.coerceAtLeast(0)
                onSongPlayed(song)
            }
            _currentPositionMs.value = controller.currentPosition.coerceAtLeast(0)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val controller = mediaController ?: return
            val duration = controller.duration
            if (duration > 0) {
                _durationMs.value = duration
            }
            if (playbackState == Player.STATE_ENDED) {
                _isPlaying.value = false
            }
        }

        override fun onRepeatModeChanged(newRepeatMode: Int) {
            _repeatMode.value = newRepeatMode
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _shuffleEnabled.value = shuffleModeEnabled
        }
    }

    init {
        initializeController()
    }

    private fun initializeController() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, DarkWaveMusicService::class.java)
        )
        val controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture.addListener({
            try {
                val controller = controllerFuture.get()
                mediaController = controller
                controller.addListener(playerListener)
                _isPlaying.value = controller.isPlaying
                _repeatMode.value = controller.repeatMode
                _shuffleEnabled.value = controller.shuffleModeEnabled
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        val controller = mediaController ?: return
        if (songs.isEmpty()) return

        _queue.value = songs
        val validIndex = startIndex.coerceIn(0, songs.lastIndex)
        _currentIndex.value = validIndex

        val mediaItems = songs.map { song ->
            MediaItem.Builder()
                .setMediaId(song.id.toString())
                .setUri(song.contentUri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(song.albumArtUri)
                        .build()
                )
                .build()
        }

        controller.setMediaItems(mediaItems, validIndex, 0L)
        controller.prepare()
        controller.play()

        val selectedSong = songs[validIndex]
        _currentSong.value = selectedSong
        _durationMs.value = selectedSong.durationMs
        _currentPositionMs.value = 0L
        onSongPlayed(selectedSong)
    }

    fun playSong(song: Song, fullQueue: List<Song>) {
        val index = fullQueue.indexOfFirst { it.id == song.id }
        if (index != -1) {
            playQueue(fullQueue, index)
        } else {
            playQueue(listOf(song), 0)
        }
    }

    fun playOrPause() {
        val controller = mediaController ?: return
        if (controller.isPlaying) {
            controller.pause()
        } else {
            if (controller.playbackState == Player.STATE_IDLE || controller.playbackState == Player.STATE_ENDED) {
                controller.prepare()
            }
            controller.play()
        }
    }

    fun pause() {
        mediaController?.pause()
    }

    fun resume() {
        val controller = mediaController ?: return
        if (controller.playbackState == Player.STATE_IDLE || controller.playbackState == Player.STATE_ENDED) {
            controller.prepare()
        }
        controller.play()
    }

    fun seekTo(positionMs: Long) {
        val controller = mediaController ?: return
        val clamped = positionMs.coerceIn(0L, _durationMs.value.coerceAtLeast(0L))
        controller.seekTo(clamped)
        _currentPositionMs.value = clamped
    }

    fun seekBy(deltaMs: Long) {
        val controller = mediaController ?: return
        val newPos = (controller.currentPosition + deltaMs).coerceIn(0L, _durationMs.value.coerceAtLeast(0L))
        seekTo(newPos)
    }

    fun skipToNext() {
        val controller = mediaController ?: return
        if (controller.hasNextMediaItem()) {
            controller.seekToNextMediaItem()
        }
    }

    fun skipToPrevious() {
        val controller = mediaController ?: return
        if (controller.currentPosition > 3000L) {
            controller.seekTo(0L)
        } else if (controller.hasPreviousMediaItem()) {
            controller.seekToPreviousMediaItem()
        } else {
            controller.seekTo(0L)
        }
    }

    fun toggleShuffle() {
        val controller = mediaController ?: return
        val next = !controller.shuffleModeEnabled
        controller.shuffleModeEnabled = next
        _shuffleEnabled.value = next
    }

    fun cycleRepeatMode() {
        val controller = mediaController ?: return
        val next = when (controller.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        controller.repeatMode = next
        _repeatMode.value = next
    }

    fun addToQueue(song: Song) {
        val controller = mediaController ?: return
        val updatedQueue = _queue.value.toMutableList().apply { add(song) }
        _queue.value = updatedQueue

        val mediaItem = MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(song.contentUri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .setArtworkUri(song.albumArtUri)
                    .build()
            )
            .build()
        controller.addMediaItem(mediaItem)
    }

    fun removeFromQueue(index: Int) {
        val controller = mediaController ?: return
        if (index in _queue.value.indices) {
            val updatedQueue = _queue.value.toMutableList().apply { removeAt(index) }
            _queue.value = updatedQueue
            controller.removeMediaItem(index)
        }
    }

    private fun startPositionTicker() {
        stopPositionTicker()
        positionTickerJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                val controller = mediaController
                if (controller != null && controller.isPlaying) {
                    _currentPositionMs.value = controller.currentPosition.coerceAtLeast(0)
                    if (controller.duration > 0) {
                        _durationMs.value = controller.duration
                    }
                }
                delay(250L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    fun release() {
        stopPositionTicker()
        mediaController?.removeListener(playerListener)
        mediaController?.release()
        mediaController = null
    }
}
