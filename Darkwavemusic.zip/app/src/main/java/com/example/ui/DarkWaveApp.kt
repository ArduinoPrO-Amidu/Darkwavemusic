package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.QueueMusic
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.FullPlayerSheet
import com.example.ui.components.MiniPlayer
import com.example.ui.components.PermissionRequestView
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SongsScreen
import com.example.ui.theme.DarkWaveBackground
import com.example.ui.theme.DarkWaveGreenOnPrimary
import com.example.ui.theme.DarkWaveGreenPrimary
import com.example.ui.theme.DarkWaveSurface
import com.example.ui.theme.DarkWaveSurfaceContainer
import com.example.ui.theme.DarkWaveTextMuted
import com.example.ui.theme.DarkWaveTextPrimary
import com.example.ui.theme.DarkWaveTextSecondary
import com.example.ui.viewmodel.MusicPlayerViewModel

@Composable
fun DarkWaveApp(
    viewModel: MusicPlayerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // State from ViewModel
    val hasStoragePermission by viewModel.hasStoragePermission.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val songsSubTab by viewModel.songsSubTab.collectAsState()
    val isPlayerSheetExpanded by viewModel.isPlayerSheetExpanded.collectAsState()

    val allSongs by viewModel.allSongs.collectAsState()
    val filteredSongs by viewModel.filteredSongs.collectAsState()
    val albums by viewModel.albums.collectAsState()
    val artists by viewModel.artists.collectAsState()
    val folders by viewModel.folders.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val favoriteSongs by viewModel.favoriteSongs.collectAsState()
    val favoriteIds by viewModel.favoriteIds.collectAsState()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val sortOrder by viewModel.sortOrder.collectAsState()

    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentPositionMs by viewModel.currentPositionMs.collectAsState()
    val durationMs by viewModel.durationMs.collectAsState()
    val repeatMode by viewModel.repeatMode.collectAsState()
    val shuffleEnabled by viewModel.shuffleEnabled.collectAsState()
    val queue by viewModel.queue.collectAsState()
    val currentIndex by viewModel.currentIndex.collectAsState()

    val sleepTimerMinutes by viewModel.sleepTimerMinutesRemaining.collectAsState()
    val songPendingPlaylist by viewModel.songPendingPlaylist.collectAsState()

    // Check permissions at launch
    LaunchedEffect(Unit) {
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
        viewModel.setPermissionGranted(granted)
    }

    // Back button handling
    BackHandler(enabled = isPlayerSheetExpanded || selectedTab != 0) {
        if (isPlayerSheetExpanded) {
            viewModel.setPlayerSheetExpanded(false)
        } else if (selectedTab != 0) {
            viewModel.setSelectedTab(0)
        }
    }

    Box(modifier = modifier.fillMaxSize().background(DarkWaveBackground)) {
        Scaffold(
            bottomBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    // Floating MiniPlayer docked directly above NavigationBar
                    MiniPlayer(
                        currentSong = currentSong,
                        isPlaying = isPlaying,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        onPlayPauseClick = { viewModel.playOrPause() },
                        onSkipNextClick = { viewModel.skipToNext() },
                        onClick = { viewModel.setPlayerSheetExpanded(true) }
                    )

                    // 4-Tab Navigation Bar
                    NavigationBar(
                        containerColor = DarkWaveSurface,
                        contentColor = DarkWaveTextPrimary,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("main_navigation_bar")
                    ) {
                        val navItems = listOf(
                            Triple("Home", Icons.Filled.Home, Icons.Outlined.Home),
                            Triple("Songs", Icons.Filled.MusicNote, Icons.Outlined.MusicNote),
                            Triple("Playlists", Icons.Filled.QueueMusic, Icons.Outlined.QueueMusic),
                            Triple("Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
                        )

                        navItems.forEachIndexed { index, item ->
                            val isSelected = selectedTab == index
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { viewModel.setSelectedTab(index) },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) item.second else item.third,
                                        contentDescription = item.first
                                    )
                                },
                                label = {
                                    Text(
                                        text = item.first,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DarkWaveGreenOnPrimary,
                                    selectedTextColor = DarkWaveGreenPrimary,
                                    indicatorColor = DarkWaveGreenPrimary,
                                    unselectedIconColor = DarkWaveTextSecondary,
                                    unselectedTextColor = DarkWaveTextMuted
                                ),
                                modifier = Modifier.testTag("nav_tab_$index")
                            )
                        }
                    }
                }
            },
            containerColor = DarkWaveBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!hasStoragePermission && selectedTab != 3) {
                    PermissionRequestView(
                        onPermissionGranted = {
                            viewModel.setPermissionGranted(true)
                        }
                    )
                } else {
                    when (selectedTab) {
                        0 -> HomeScreen(
                            allSongs = allSongs,
                            recentlyPlayed = recentlyPlayed,
                            favoriteSongs = favoriteSongs,
                            favoriteIds = favoriteIds,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            isScanning = isScanning,
                            onPlaySong = { song, q -> viewModel.playSong(song, q) },
                            onShuffleAll = { viewModel.shuffleAll() },
                            onRescan = { viewModel.scanSongs() },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onAddToPlaylist = { viewModel.openAddToPlaylist(it) },
                            onAddToQueue = { viewModel.addToQueue(it) },
                            onNavigateToSongs = { viewModel.setSelectedTab(1) }
                        )
                        1 -> SongsScreen(
                            songs = filteredSongs,
                            allSongs = allSongs,
                            albums = albums,
                            artists = artists,
                            folders = folders,
                            favoriteIds = favoriteIds,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            searchQuery = searchQuery,
                            sortOrder = sortOrder,
                            subTab = songsSubTab,
                            onSearchChange = { viewModel.searchQuery.value = it },
                            onSortChange = { viewModel.sortOrder.value = it },
                            onSubTabChange = { viewModel.setSongsSubTab(it) },
                            onPlaySong = { song, q -> viewModel.playSong(song, q) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onAddToPlaylist = { viewModel.openAddToPlaylist(it) },
                            onAddToQueue = { viewModel.addToQueue(it) }
                        )
                        2 -> PlaylistsScreen(
                            playlists = playlists,
                            favoriteSongs = favoriteSongs,
                            favoriteIds = favoriteIds,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            onCreatePlaylist = { viewModel.createPlaylist(it) },
                            onRenamePlaylist = { id, name -> viewModel.renamePlaylist(id, name) },
                            onDeletePlaylist = { viewModel.deletePlaylist(it) },
                            onPlaySong = { song, q -> viewModel.playSong(song, q) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onAddToPlaylist = { viewModel.openAddToPlaylist(it) },
                            onAddToQueue = { viewModel.addToQueue(it) },
                            onRemoveSongFromPlaylist = { pId, sId -> viewModel.removeSongFromPlaylist(pId, sId) },
                            getSongsForPlaylist = { viewModel.getSongsForPlaylist(it) }
                        )
                        3 -> SettingsScreen(
                            songCount = allSongs.size,
                            playlistCount = playlists.size,
                            hasStoragePermission = hasStoragePermission,
                            isScanning = isScanning,
                            sleepTimerMinutesRemaining = sleepTimerMinutes,
                            onRescanStorage = { viewModel.scanSongs() },
                            onRequestPermissions = {
                                viewModel.setPermissionGranted(false)
                            },
                            onSetSleepTimer = { viewModel.setSleepTimer(it) }
                        )
                    }
                }
            }
        }

        // Full Screen Player Overlay
        FullPlayerSheet(
            isVisible = isPlayerSheetExpanded,
            currentSong = currentSong,
            isPlaying = isPlaying,
            currentPositionMs = currentPositionMs,
            durationMs = durationMs,
            repeatMode = repeatMode,
            shuffleEnabled = shuffleEnabled,
            isFavorite = currentSong?.let { favoriteIds.contains(it.id) } ?: false,
            queue = queue,
            currentIndex = currentIndex,
            onDismiss = { viewModel.setPlayerSheetExpanded(false) },
            onPlayPauseClick = { viewModel.playOrPause() },
            onSkipNextClick = { viewModel.skipToNext() },
            onSkipPreviousClick = { viewModel.skipToPrevious() },
            onSeekTo = { viewModel.seekTo(it) },
            onSeekBy = { viewModel.seekBy(it) },
            onToggleShuffle = { viewModel.toggleShuffle() },
            onCycleRepeatMode = { viewModel.cycleRepeatMode() },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            onAddToPlaylist = { viewModel.openAddToPlaylist(it) },
            onPlayQueueIndex = { index ->
                if (index in queue.indices) {
                    viewModel.playSong(queue[index], queue)
                }
            },
            onRemoveFromQueue = { viewModel.removeFromQueue(it) }
        )

        // Add to Playlist Dialog
        AddToPlaylistDialog(
            song = songPendingPlaylist,
            playlists = playlists,
            onDismiss = { viewModel.closeAddToPlaylist() },
            onSelectPlaylist = { playlistId ->
                songPendingPlaylist?.let { song ->
                    viewModel.addSongToPlaylist(playlistId, song.id)
                }
            },
            onCreatePlaylist = { name ->
                viewModel.createPlaylist(name)
            }
        )
    }
}
