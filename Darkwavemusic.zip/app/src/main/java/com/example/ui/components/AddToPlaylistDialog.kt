package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.db.PlaylistEntity
import com.example.data.model.Song
import com.example.ui.theme.DarkWaveGreenOnPrimary
import com.example.ui.theme.DarkWaveGreenPrimary
import com.example.ui.theme.DarkWaveSurfaceContainer
import com.example.ui.theme.DarkWaveSurfaceContainerHigh
import com.example.ui.theme.DarkWaveTextMuted
import com.example.ui.theme.DarkWaveTextPrimary
import com.example.ui.theme.DarkWaveTextSecondary

@Composable
fun AddToPlaylistDialog(
    song: Song?,
    playlists: List<PlaylistEntity>,
    onDismiss: () -> Unit,
    onSelectPlaylist: (Long) -> Unit,
    onCreatePlaylist: (String) -> Unit
) {
    if (song == null) return

    var isCreatingNew by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isCreatingNew) "New Playlist" else "Add to Playlist",
                style = MaterialTheme.typography.titleLarge.copy(
                    color = DarkWaveTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            )
        },
        text = {
            if (isCreatingNew) {
                Column {
                    Text(
                        text = "Enter a name for your new playlist:",
                        style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("Playlist name...", color = DarkWaveTextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DarkWaveGreenPrimary,
                            unfocusedBorderColor = DarkWaveTextMuted,
                            focusedTextColor = DarkWaveTextPrimary,
                            unfocusedTextColor = DarkWaveTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("new_playlist_input")
                    )
                }
            } else {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Song: ${song.title}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = DarkWaveGreenPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Create new playlist shortcut
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkWaveSurfaceContainerHigh)
                            .clickable { isCreatingNew = true }
                            .padding(12.dp)
                            .testTag("create_playlist_row"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = DarkWaveGreenPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Create New Playlist",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = DarkWaveGreenPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (playlists.isEmpty()) {
                        Text(
                            text = "No playlists created yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextMuted),
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(playlists) { playlist ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(DarkWaveSurfaceContainerHigh.copy(alpha = 0.5f))
                                        .clickable { onSelectPlaylist(playlist.id) }
                                        .padding(12.dp)
                                        .testTag("playlist_row_${playlist.id}"),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlaylistPlay,
                                        contentDescription = null,
                                        tint = DarkWaveTextSecondary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = playlist.name,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = DarkWaveTextPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (isCreatingNew) {
                Button(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            onCreatePlaylist(newPlaylistName.trim())
                            isCreatingNew = false
                            newPlaylistName = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DarkWaveGreenPrimary,
                        contentColor = DarkWaveGreenOnPrimary
                    ),
                    enabled = newPlaylistName.isNotBlank(),
                    modifier = Modifier.testTag("save_new_playlist_btn")
                ) {
                    Text("Create")
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (isCreatingNew) {
                        isCreatingNew = false
                    } else {
                        onDismiss()
                    }
                }
            ) {
                Text("Cancel", color = DarkWaveTextSecondary)
            }
        },
        containerColor = DarkWaveSurfaceContainer
    )
}
