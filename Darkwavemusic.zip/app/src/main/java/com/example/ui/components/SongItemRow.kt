package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Song
import com.example.ui.theme.DarkWaveGreenPrimary
import com.example.ui.theme.DarkWaveSurfaceContainer
import com.example.ui.theme.DarkWaveSurfaceContainerHigh
import com.example.ui.theme.DarkWaveTextMuted
import com.example.ui.theme.DarkWaveTextPrimary
import com.example.ui.theme.DarkWaveTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SongItemRow(
    song: Song,
    isCurrentSong: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onAddToQueue: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }

    val rowBackground = if (isCurrentSong) {
        DarkWaveGreenPrimary.copy(alpha = 0.08f)
    } else {
        Color.Transparent
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(rowBackground)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("song_item_${song.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Artwork
        SongArtwork(
            artworkUri = song.albumArtUri,
            size = 48.dp,
            cornerRadius = 8.dp,
            isPlaying = isCurrentSong && isPlaying,
            contentDescription = song.title
        )

        Spacer(modifier = Modifier.width(12.dp))

        // Title & Artist
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isCurrentSong && isPlaying) {
                    MiniVisualizer(modifier = Modifier.padding(end = 6.dp))
                }
                Text(
                    text = song.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = if (isCurrentSong) DarkWaveGreenPrimary else DarkWaveTextPrimary,
                        fontWeight = if (isCurrentSong) FontWeight.Bold else FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${song.artist} • ${song.album}",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = DarkWaveTextSecondary
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Duration text
        Text(
            text = song.formattedDuration,
            style = MaterialTheme.typography.labelSmall.copy(color = DarkWaveTextMuted),
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        // Favorite Toggle Button
        IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier.size(36.dp).testTag("fav_btn_${song.id}")
        ) {
            Icon(
                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                tint = if (isFavorite) DarkWaveGreenPrimary else DarkWaveTextMuted,
                modifier = Modifier.size(20.dp)
            )
        }

        // More options dropdown
        Box {
            IconButton(
                onClick = { menuExpanded = true },
                modifier = Modifier.size(36.dp).testTag("more_btn_${song.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "More options",
                    tint = DarkWaveTextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(DarkWaveSurfaceContainer)
            ) {
                DropdownMenuItem(
                    text = { Text("Play Next / Add to Queue", color = DarkWaveTextPrimary) },
                    leadingIcon = {
                        Icon(Icons.Default.QueueMusic, contentDescription = null, tint = DarkWaveGreenPrimary)
                    },
                    onClick = {
                        menuExpanded = false
                        onAddToQueue()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Add to Playlist", color = DarkWaveTextPrimary) },
                    leadingIcon = {
                        Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = DarkWaveGreenPrimary)
                    },
                    onClick = {
                        menuExpanded = false
                        onAddToPlaylist()
                    }
                )
                DropdownMenuItem(
                    text = { Text(if (isFavorite) "Remove Favorite" else "Add to Favorites", color = DarkWaveTextPrimary) },
                    leadingIcon = {
                        Icon(
                            if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = null,
                            tint = DarkWaveGreenPrimary
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onToggleFavorite()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Track Details", color = DarkWaveTextPrimary) },
                    leadingIcon = {
                        Icon(Icons.Default.Info, contentDescription = null, tint = DarkWaveTextSecondary)
                    },
                    onClick = {
                        menuExpanded = false
                        showDetailsDialog = true
                    }
                )
            }
        }
    }

    if (showDetailsDialog) {
        SongDetailsDialog(
            song = song,
            isFavorite = isFavorite,
            onToggleFavorite = onToggleFavorite,
            onDismiss = { showDetailsDialog = false }
        )
    }
}

@Composable
fun MiniVisualizer(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "vis")
    val h1 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(400), RepeatMode.Reverse),
        label = "h1"
    )
    val h2 by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(350), RepeatMode.Reverse),
        label = "h2"
    )
    val h3 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "h3"
    )

    Row(
        modifier = modifier.height(14.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Box(Modifier.width(2.5.dp).height((14 * h1).dp).clip(RoundedCornerShape(1.dp)).background(DarkWaveGreenPrimary))
        Box(Modifier.width(2.5.dp).height((14 * h2).dp).clip(RoundedCornerShape(1.dp)).background(DarkWaveGreenPrimary))
        Box(Modifier.width(2.5.dp).height((14 * h3).dp).clip(RoundedCornerShape(1.dp)).background(DarkWaveGreenPrimary))
    }
}

@Composable
fun SongDetailsDialog(
    song: Song,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onDismiss: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }
    val formattedDate = remember(song.dateAdded) {
        if (song.dateAdded > 0) {
            dateFormat.format(Date(song.dateAdded * 1000L))
        } else "Unknown"
    }
    val sizeMb = remember(song.sizeBytes) {
        String.format(Locale.getDefault(), "%.2f MB", song.sizeBytes / (1024f * 1024f))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Track Details", color = DarkWaveTextPrimary, fontWeight = FontWeight.Bold)

                // Heart Toggle Icon Button in the dialog title bar
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("details_dialog_favorite_toggle")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                        tint = if (isFavorite) DarkWaveGreenPrimary else DarkWaveTextMuted,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Header with artwork and favorite status banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isFavorite) DarkWaveGreenPrimary.copy(alpha = 0.12f) else DarkWaveSurfaceContainerHigh)
                        .clickable(onClick = onToggleFavorite)
                        .padding(10.dp)
                        .testTag("details_favorite_banner"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SongArtwork(
                        artworkUri = song.albumArtUri,
                        size = 46.dp,
                        cornerRadius = 8.dp,
                        isPlaying = isFavorite
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isFavorite) "In Favorites" else "Add to Favorites",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = if (isFavorite) DarkWaveGreenPrimary else DarkWaveTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = if (isFavorite) "Saved in Room database • Tap to remove" else "Tap heart to add to Home favorites",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = DarkWaveTextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = null,
                        tint = if (isFavorite) DarkWaveGreenPrimary else DarkWaveTextMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }

                DetailRow(label = "Title", value = song.title)
                DetailRow(label = "Artist", value = song.artist)
                DetailRow(label = "Album", value = song.album)
                DetailRow(label = "Duration", value = song.formattedDuration)
                DetailRow(label = "File Size", value = sizeMb)
                DetailRow(label = "Added", value = formattedDate)
                DetailRow(label = "File Path", value = song.dataPath.ifBlank { "Content Storage" })
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = DarkWaveGreenPrimary)
            }
        },
        containerColor = DarkWaveSurfaceContainer
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = DarkWaveGreenPrimary))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary),
            fontSize = 12.sp
        )
    }
}
