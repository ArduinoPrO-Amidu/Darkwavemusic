package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.db.PlaylistEntity
import com.example.data.model.Song
import com.example.ui.components.SongItemRow
import com.example.ui.theme.DarkWaveGreenOnPrimary
import com.example.ui.theme.DarkWaveGreenPrimary
import com.example.ui.theme.DarkWaveSurface
import com.example.ui.theme.DarkWaveSurfaceContainer
import com.example.ui.theme.DarkWaveSurfaceContainerHigh
import com.example.ui.theme.DarkWaveTextMuted
import com.example.ui.theme.DarkWaveTextPrimary
import com.example.ui.theme.DarkWaveTextSecondary
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PlaylistsScreen(
    playlists: List<PlaylistEntity>,
    favoriteSongs: List<Song>,
    favoriteIds: Set<Long>,
    currentSong: Song?,
    isPlaying: Boolean,
    onCreatePlaylist: (String) -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onPlaySong: (Song, List<Song>) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onRemoveSongFromPlaylist: (Long, Long) -> Unit,
    getSongsForPlaylist: (Long) -> StateFlow<List<Song>>,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistToRename by remember { mutableStateOf<PlaylistEntity?>(null) }
    var playlistToDelete by remember { mutableStateOf<PlaylistEntity?>(null) }
    var activePlaylistDetail by remember { mutableStateOf<PlaylistEntity?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("playlists_screen")
    ) {
        if (activePlaylistDetail != null) {
            val playlist = activePlaylistDetail!!
            val playlistSongsFlow = remember(playlist.id) { getSongsForPlaylist(playlist.id) }
            val playlistSongs by playlistSongsFlow.collectAsState()

            PlaylistDetailView(
                playlist = playlist,
                songs = playlistSongs,
                favoriteIds = favoriteIds,
                currentSong = currentSong,
                isPlaying = isPlaying,
                onBack = { activePlaylistDetail = null },
                onPlayAll = {
                    if (playlistSongs.isNotEmpty()) {
                        onPlaySong(playlistSongs.first(), playlistSongs)
                    }
                },
                onShuffle = {
                    if (playlistSongs.isNotEmpty()) {
                        val shuffled = playlistSongs.shuffled()
                        onPlaySong(shuffled.first(), shuffled)
                    }
                },
                onPlaySong = { song -> onPlaySong(song, playlistSongs) },
                onToggleFavorite = onToggleFavorite,
                onAddToPlaylist = onAddToPlaylist,
                onAddToQueue = onAddToQueue,
                onRemoveFromPlaylist = { songId -> onRemoveSongFromPlaylist(playlist.id, songId) }
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Your Playlists",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DarkWaveTextPrimary
                                )
                            )
                            Text(
                                text = "${playlists.size} Custom Playlists",
                                style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary)
                            )
                        }

                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkWaveGreenPrimary,
                                contentColor = DarkWaveGreenOnPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("create_playlist_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("New Playlist", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Built-in Favorites Playlist Card
                item {
                    PlaylistCard(
                        title = "Favorite Tracks",
                        subtitle = "${favoriteSongs.size} favorited songs",
                        isFavorites = true,
                        onClick = {
                            if (favoriteSongs.isNotEmpty()) {
                                onPlaySong(favoriteSongs.first(), favoriteSongs)
                            }
                        },
                        onRename = null,
                        onDelete = null
                    )
                }

                if (playlists.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlaylistPlay,
                                    contentDescription = null,
                                    tint = DarkWaveGreenPrimary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "No Custom Playlists Yet",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = DarkWaveTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Create custom playlists to organize your favorite albums, synthwave mixes, and offline tracks.",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = DarkWaveTextSecondary,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { showCreateDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = DarkWaveGreenPrimary,
                                        contentColor = DarkWaveGreenOnPrimary
                                    )
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Create Playlist")
                                }
                            }
                        }
                    }
                } else {
                    items(playlists, key = { it.id }) { playlist ->
                        PlaylistCard(
                            title = playlist.name,
                            subtitle = "Tap to view & manage tracks",
                            isFavorites = false,
                            onClick = { activePlaylistDetail = playlist },
                            onRename = { playlistToRename = playlist },
                            onDelete = { playlistToDelete = playlist }
                        )
                    }
                }
            }
        }

        // Dialog: Create Playlist
        if (showCreateDialog) {
            PlaylistNameDialog(
                title = "Create New Playlist",
                confirmButtonLabel = "Create",
                initialName = "",
                onDismiss = { showCreateDialog = false },
                onConfirm = { name ->
                    onCreatePlaylist(name)
                    showCreateDialog = false
                }
            )
        }

        // Dialog: Rename Playlist
        playlistToRename?.let { playlist ->
            PlaylistNameDialog(
                title = "Rename Playlist",
                confirmButtonLabel = "Save",
                initialName = playlist.name,
                onDismiss = { playlistToRename = null },
                onConfirm = { newName ->
                    onRenamePlaylist(playlist.id, newName)
                    playlistToRename = null
                }
            )
        }

        // Dialog: Delete Playlist Confirmation
        playlistToDelete?.let { playlist ->
            AlertDialog(
                onDismissRequest = { playlistToDelete = null },
                title = { Text("Delete Playlist?", color = DarkWaveTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "Are you sure you want to delete \"${playlist.name}\"? Your offline audio files will not be deleted.",
                        color = DarkWaveTextSecondary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onDeletePlaylist(playlist.id)
                            playlistToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { playlistToDelete = null }) {
                        Text("Cancel", color = DarkWaveTextSecondary)
                    }
                },
                containerColor = DarkWaveSurfaceContainer
            )
        }
    }
}

@Composable
fun PlaylistCard(
    title: String,
    subtitle: String,
    isFavorites: Boolean,
    onClick: () -> Unit,
    onRename: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("playlist_card_$title"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isFavorites) DarkWaveGreenPrimary.copy(alpha = 0.2f) else DarkWaveSurfaceContainerHigh
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isFavorites) Icons.Default.QueueMusic else Icons.Default.PlaylistPlay,
                    contentDescription = null,
                    tint = DarkWaveGreenPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = DarkWaveTextPrimary,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (onRename != null || onDelete != null) {
                Box {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = DarkWaveTextMuted)
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        modifier = Modifier.background(DarkWaveSurfaceContainerHigh)
                    ) {
                        if (onRename != null) {
                            DropdownMenuItem(
                                text = { Text("Rename", color = DarkWaveTextPrimary) },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = DarkWaveGreenPrimary) },
                                onClick = {
                                    menuExpanded = false
                                    onRename()
                                }
                            )
                        }
                        if (onDelete != null) {
                            DropdownMenuItem(
                                text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    menuExpanded = false
                                    onDelete()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailView(
    playlist: PlaylistEntity,
    songs: List<Song>,
    favoriteIds: Set<Long>,
    currentSong: Song?,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onPlaySong: (Song) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    onRemoveFromPlaylist: (Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("playlist_detail_view"),
        contentPadding = PaddingValues(bottom = 120.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DarkWaveTextPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = playlist.name,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DarkWaveTextPrimary
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${songs.size} tracks",
                        style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveGreenPrimary)
                    )
                }
            }
        }

        // Quick Action Buttons
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onPlayAll,
                    enabled = songs.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DarkWaveGreenPrimary,
                        contentColor = DarkWaveGreenOnPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Play All", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onShuffle,
                    enabled = songs.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DarkWaveSurfaceContainerHigh,
                        contentColor = DarkWaveTextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Shuffle, contentDescription = null, tint = DarkWaveGreenPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Shuffle", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (songs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "This playlist is empty.\nAdd tracks from the Songs or Home screen via the 3-dots menu.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = DarkWaveTextMuted,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    )
                }
            }
        } else {
            items(songs, key = { it.id }) { song ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SongItemRow(
                        song = song,
                        isCurrentSong = currentSong?.id == song.id,
                        isPlaying = isPlaying && currentSong?.id == song.id,
                        isFavorite = favoriteIds.contains(song.id),
                        onClick = { onPlaySong(song) },
                        onToggleFavorite = { onToggleFavorite(song) },
                        onAddToPlaylist = { onAddToPlaylist(song) },
                        onAddToQueue = { onAddToQueue(song) },
                        modifier = Modifier.weight(1f).padding(start = 8.dp)
                    )

                    IconButton(
                        onClick = { onRemoveFromPlaylist(song.id) },
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Remove from playlist",
                            tint = DarkWaveTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistNameDialog(
    title: String,
    confirmButtonLabel: String,
    initialName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = DarkWaveTextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                placeholder = { Text("Playlist name...", color = DarkWaveTextMuted) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DarkWaveGreenPrimary,
                    unfocusedBorderColor = Color(0xFF23313C),
                    focusedTextColor = DarkWaveTextPrimary,
                    unfocusedTextColor = DarkWaveTextPrimary
                ),
                modifier = Modifier.fillMaxWidth().testTag("playlist_name_input")
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) onConfirm(name.trim())
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = DarkWaveGreenPrimary,
                    contentColor = DarkWaveGreenOnPrimary
                ),
                enabled = name.isNotBlank()
            ) {
                Text(confirmButtonLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = DarkWaveTextSecondary)
            }
        },
        containerColor = DarkWaveSurfaceContainer
    )
}
