package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkWaveGreenOnPrimary
import com.example.ui.theme.DarkWaveGreenPrimary
import com.example.ui.theme.DarkWaveSurfaceContainer
import com.example.ui.theme.DarkWaveSurfaceContainerHigh
import com.example.ui.theme.DarkWaveTextMuted
import com.example.ui.theme.DarkWaveTextPrimary
import com.example.ui.theme.DarkWaveTextSecondary

@Composable
fun SettingsScreen(
    songCount: Int,
    playlistCount: Int,
    hasStoragePermission: Boolean,
    isScanning: Boolean,
    sleepTimerMinutesRemaining: Int?,
    onRescanStorage: () -> Unit,
    onRequestPermissions: () -> Unit,
    onSetSleepTimer: (Int?) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings & Engine",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = DarkWaveTextPrimary
                )
            )
        }

        // App Branding Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkWaveGreenPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = DarkWaveGreenPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "DarkWave Music v1.0",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DarkWaveTextPrimary
                                )
                            )
                            Text(
                                text = "100% Offline • No Telemetry",
                                style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveGreenPrimary)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "DarkWave is an offline music player powered by Android Media3 ExoPlayer and Room database persistence. Your music, playlists, and history never leave this device.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary)
                    )
                }
            }
        }

        // Sleep Timer Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Snooze,
                            contentDescription = null,
                            tint = DarkWaveGreenPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Sleep Timer",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = DarkWaveTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        if (sleepTimerMinutesRemaining != null && sleepTimerMinutesRemaining > 0) {
                            Text(
                                text = "$sleepTimerMinutesRemaining min left",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = DarkWaveGreenPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Automatically stops playback when the timer finishes.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val timerOptions = listOf(null to "Off", 15 to "15m", 30 to "30m", 45 to "45m", 60 to "60m")
                        timerOptions.forEach { (mins, label) ->
                            val isSelected = sleepTimerMinutesRemaining == mins || (mins == null && sleepTimerMinutesRemaining == null)
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSetSleepTimer(mins) },
                                label = { Text(label, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DarkWaveGreenPrimary,
                                    selectedLabelColor = DarkWaveGreenOnPrimary,
                                    containerColor = DarkWaveSurfaceContainerHigh,
                                    labelColor = DarkWaveTextSecondary
                                )
                            )
                        }
                    }
                }
            }
        }

        // Media Scanner Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Storage,
                            contentDescription = null,
                            tint = DarkWaveGreenPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Local Media Library",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = DarkWaveTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Currently indexed: $songCount songs across $playlistCount playlists.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary)
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onRescanStorage,
                        enabled = !isScanning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DarkWaveGreenPrimary,
                            contentColor = DarkWaveGreenOnPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("rescan_storage_btn")
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = DarkWaveGreenOnPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Scanning Files...")
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Rescan Device Storage")
                        }
                    }
                }
            }
        }

        // Engine & Playback Specs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = DarkWaveGreenPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Playback Engine Specifications",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = DarkWaveTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    SpecRow(label = "Engine", value = "AndroidX Media3 ExoPlayer 1.5.1")
                    SpecRow(label = "Background Service", value = "MediaSessionService + Lockscreen Controls")
                    SpecRow(label = "Audio Focus", value = "Transient Ducking & Auto Pause on Unplug")
                    SpecRow(label = "Supported Decoders", value = "MP3, AAC, FLAC, WAV, OGG, M4A, Opus")
                    SpecRow(label = "Database", value = "Room SQLite (Local Playlists & History)")
                }
            }
        }

        // Permissions Status
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (hasStoragePermission) Icons.Default.CheckCircle else Icons.Default.Security,
                                contentDescription = null,
                                tint = if (hasStoragePermission) DarkWaveGreenPrimary else MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Storage Permission",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = DarkWaveTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (hasStoragePermission) "Granted (Full access to local audio)" else "Permission required to access audio files",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (hasStoragePermission) DarkWaveGreenPrimary else DarkWaveTextSecondary
                            )
                        )
                    }

                    if (!hasStoragePermission) {
                        Button(
                            onClick = onRequestPermissions,
                            colors = ButtonDefaults.buttonColors(containerColor = DarkWaveGreenPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Grant", color = DarkWaveGreenOnPrimary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = DarkWaveGreenPrimary))
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary))
    }
}
