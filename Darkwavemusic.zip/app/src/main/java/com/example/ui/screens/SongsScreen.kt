package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.MusicFolder
import com.example.data.model.Song
import com.example.ui.components.SongArtwork
import com.example.ui.components.SongItemRow
import com.example.ui.theme.DarkWaveGreenOnPrimary
import com.example.ui.theme.DarkWaveGreenPrimary
import com.example.ui.theme.DarkWaveSurface
import com.example.ui.theme.DarkWaveSurfaceContainer
import com.example.ui.theme.DarkWaveSurfaceContainerHigh
import com.example.ui.theme.DarkWaveTextMuted
import com.example.ui.theme.DarkWaveTextPrimary
import com.example.ui.theme.DarkWaveTextSecondary
import com.example.ui.viewmodel.SortOrder

@Composable
fun SongsScreen(
    songs: List<Song>,
    allSongs: List<Song>,
    albums: List<Album>,
    artists: List<Artist>,
    folders: List<MusicFolder>,
    favoriteIds: Set<Long>,
    currentSong: Song?,
    isPlaying: Boolean,
    searchQuery: String,
    sortOrder: SortOrder,
    subTab: Int,
    onSearchChange: (String) -> Unit,
    onSortChange: (SortOrder) -> Unit,
    onSubTabChange: (Int) -> Unit,
    onPlaySong: (Song, List<Song>) -> Unit,
    onToggleFavorite: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    onAddToQueue: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilterTitle by remember { mutableStateOf<String?>(null) }
    var activeFilterType by remember { mutableStateOf<String?>(null) } // "album", "artist", "folder"

    val displayedSongs = remember(songs, allSongs, selectedFilterTitle, activeFilterType) {
        if (selectedFilterTitle == null) {
            songs
        } else {
            when (activeFilterType) {
                "album" -> allSongs.filter { it.album == selectedFilterTitle }
                "artist" -> allSongs.filter { it.artist == selectedFilterTitle }
                "folder" -> allSongs.filter { it.folderPath == selectedFilterTitle }
                else -> songs
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("songs_screen")
    ) {
        // Search Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("songs_search_input"),
            placeholder = { Text("Search songs, artists, albums...", color = DarkWaveTextMuted) },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = DarkWaveGreenPrimary)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = DarkWaveTextMuted)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = DarkWaveGreenPrimary,
                unfocusedBorderColor = Color(0xFF23313C),
                focusedContainerColor = DarkWaveSurfaceContainer,
                unfocusedContainerColor = DarkWaveSurfaceContainer,
                focusedTextColor = DarkWaveTextPrimary,
                unfocusedTextColor = DarkWaveTextPrimary
            )
        )

        // If filtered by an album/artist/folder, show active filter bar with back button
        if (selectedFilterTitle != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkWaveGreenPrimary.copy(alpha = 0.1f))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        selectedFilterTitle = null
                        activeFilterType = null
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = DarkWaveGreenPrimary
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${activeFilterType?.replaceFirstChar { it.uppercase() }}: $selectedFilterTitle",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = DarkWaveTextPrimary,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${displayedSongs.size} tracks",
                        style = MaterialTheme.typography.labelSmall.copy(color = DarkWaveGreenPrimary)
                    )
                }
            }
        } else {
            // Sub-tabs: Songs, Albums, Artists, Folders
            TabRow(
                selectedTabIndex = subTab,
                containerColor = Color.Transparent,
                contentColor = DarkWaveGreenPrimary,
                indicator = { tabPositions ->
                    if (subTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[subTab]),
                            color = DarkWaveGreenPrimary,
                            height = 3.dp
                        )
                    }
                },
                divider = {}
            ) {
                val tabTitles = listOf(
                    "Tracks (${allSongs.size})",
                    "Albums (${albums.size})",
                    "Artists (${artists.size})",
                    "Folders (${folders.size})"
                )
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = subTab == index,
                        onClick = { onSubTabChange(index) },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = if (subTab == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (subTab == index) DarkWaveGreenPrimary else DarkWaveTextSecondary
                                ),
                                maxLines = 1
                            )
                        },
                        modifier = Modifier.testTag("songs_subtab_$index")
                    )
                }
            }
        }

        // SubTab Content
        if (selectedFilterTitle != null || subTab == 0) {
            // Sort bar (only for Songs list)
            if (selectedFilterTitle == null) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = "Sort",
                            tint = DarkWaveTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    items(SortOrder.values()) { order ->
                        FilterChip(
                            selected = sortOrder == order,
                            onClick = { onSortChange(order) },
                            label = { Text(order.displayName, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DarkWaveGreenPrimary,
                                selectedLabelColor = DarkWaveGreenOnPrimary,
                                containerColor = DarkWaveSurfaceContainer,
                                labelColor = DarkWaveTextSecondary
                            )
                        )
                    }
                }
            }

            // Songs List
            if (displayedSongs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isNotEmpty()) "No tracks matching \"$searchQuery\"" else "No songs found in this view",
                        style = MaterialTheme.typography.bodyLarge.copy(color = DarkWaveTextMuted)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    items(displayedSongs, key = { it.id }) { song ->
                        SongItemRow(
                            song = song,
                            isCurrentSong = currentSong?.id == song.id,
                            isPlaying = isPlaying && currentSong?.id == song.id,
                            isFavorite = favoriteIds.contains(song.id),
                            onClick = { onPlaySong(song, displayedSongs) },
                            onToggleFavorite = { onToggleFavorite(song) },
                            onAddToPlaylist = { onAddToPlaylist(song) },
                            onAddToQueue = { onAddToQueue(song) },
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
            }
        } else if (subTab == 1) {
            // Albums Grid
            if (albums.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No albums detected", color = DarkWaveTextMuted)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(albums, key = { it.id }) { album ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFilterTitle = album.name
                                    activeFilterType = "album"
                                },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkWaveSurfaceContainer)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                SongArtwork(
                                    artworkUri = album.albumArtUri,
                                    size = 150.dp,
                                    cornerRadius = 10.dp,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = album.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = DarkWaveTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${album.artist} • ${album.songCount} songs",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = DarkWaveTextSecondary,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        } else if (subTab == 2) {
            // Artists List
            if (artists.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No artists detected", color = DarkWaveTextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    items(artists, key = { it.id }) { artist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFilterTitle = artist.name
                                    activeFilterType = "artist"
                                }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(DarkWaveGreenPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = DarkWaveGreenPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = artist.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = DarkWaveTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "${artist.songCount} songs • ${artist.albumCount} albums",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = DarkWaveTextSecondary)
                                )
                            }
                        }
                    }
                }
            }
        } else if (subTab == 3) {
            // Folders List
            if (folders.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No music folders detected", color = DarkWaveTextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 120.dp)
                ) {
                    items(folders, key = { it.path }) { folder ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFilterTitle = folder.path
                                    activeFilterType = "folder"
                                }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DarkWaveSurfaceContainerHigh),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = null,
                                    tint = DarkWaveGreenPrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = folder.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = DarkWaveTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "${folder.songCount} songs • ${folder.path}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = DarkWaveTextSecondary,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
