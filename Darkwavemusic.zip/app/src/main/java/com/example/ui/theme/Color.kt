package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DarkWave Music - Premium Dark & Emerald Green Palette
val DarkWaveBackground = Color(0xFF080B0E)
val DarkWaveSurface = Color(0xFF10151A)
val DarkWaveSurfaceContainer = Color(0xFF161E24)
val DarkWaveSurfaceContainerHigh = Color(0xFF1D2730)
val DarkWaveSurfaceVariant = Color(0xFF222D37)

val DarkWaveGreenPrimary = Color(0xFF00E676)
val DarkWaveGreenOnPrimary = Color(0xFF00240E)
val DarkWaveGreenContainer = Color(0xFF07381F)
val DarkWaveGreenOnContainer = Color(0xFF7DFFB3)

val DarkWaveGreenSecondary = Color(0xFF10B981)
val DarkWaveGreenSecondaryContainer = Color(0xFF0D3A2C)
val DarkWaveGreenTertiary = Color(0xFF34D399)

val DarkWaveTextPrimary = Color(0xFFF8FAFC)
val DarkWaveTextSecondary = Color(0xFF94A3B8)
val DarkWaveTextMuted = Color(0xFF64748B)

val DarkWaveOutline = Color(0xFF273642)
val DarkWaveOutlineVariant = Color(0xFF18222A)

val DarkWaveError = Color(0xFFEF4444)
val DarkWaveOnError = Color(0xFF450A0A)
