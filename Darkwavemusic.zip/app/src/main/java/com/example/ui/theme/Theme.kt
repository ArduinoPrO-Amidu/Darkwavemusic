package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkWaveColorScheme = darkColorScheme(
    primary = DarkWaveGreenPrimary,
    onPrimary = DarkWaveGreenOnPrimary,
    primaryContainer = DarkWaveGreenContainer,
    onPrimaryContainer = DarkWaveGreenOnContainer,
    secondary = DarkWaveGreenSecondary,
    onSecondary = DarkWaveGreenOnPrimary,
    secondaryContainer = DarkWaveGreenSecondaryContainer,
    onSecondaryContainer = DarkWaveGreenOnContainer,
    tertiary = DarkWaveGreenTertiary,
    background = DarkWaveBackground,
    onBackground = DarkWaveTextPrimary,
    surface = DarkWaveSurface,
    onSurface = DarkWaveTextPrimary,
    surfaceVariant = DarkWaveSurfaceContainer,
    onSurfaceVariant = DarkWaveTextSecondary,
    outline = DarkWaveOutline,
    outlineVariant = DarkWaveOutlineVariant,
    error = DarkWaveError,
    onError = DarkWaveOnError
)

@Composable
fun DarkWaveTheme(
    darkTheme: Boolean = true, // DarkWave is primarily designed as a dark/night aesthetic music player
    content: @Composable () -> Unit
) {
    val colorScheme = DarkWaveColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DarkWaveBackground.toArgb()
                window.navigationBarColor = DarkWaveBackground.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Retain alias for existing callers
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) = DarkWaveTheme(darkTheme = darkTheme, content = content)
