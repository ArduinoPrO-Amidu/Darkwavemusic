package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import com.example.data.local.db.DarkWaveDatabase
import com.example.data.local.db.PlaylistEntity
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.MusicFolder
import com.example.data.model.Song
import com.example.data.repository.MediaStoreScanner
import com.example.data.repository.MusicRepository
import com.example.playback.DarkWavePlaybackController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class SortOrder(val displayName: String) {
    TITLE("Title (A-Z)"),
    ARTIST("Artist"),
    DURATION("Duration"),
    DATE_ADDED("Recently Added")
}

class MusicPlayerViewModel(
    application: Application,
    private val repository: MusicRepository,
    private val playbackController: DarkWavePlaybackController
) : AndroidViewModel(application) {

    // Permissions
    private val _hasStoragePermission = MutableStateFlow(false)
    val hasStoragePermission: StateFlow<Boolean> = _hasStoragePermission.asStateFlow()

    // Navigation and UI state
    private val _selectedTab = MutableStateFlow(0) // 0=Home, 1=Songs, 2=Playlists, 3=Settings
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _songsSubTab = MutableStateFlow(0) // 0=Tracks, 1=Albums, 2=Artists, 3=Folders
    val songsSubTab: StateFlow<Int> = _songsSubTab.asStateFlow()

    private val _isPlayerSheetExpanded = MutableStateFlow(false)
    val isPlayerSheetExpanded: StateFlow<Boolean> = _isPlayerSheetExpanded.asStateFlow()

    // Search and Sorting
    val searchQuery = MutableStateFlow("")
    val sortOrder = MutableStateFlow(SortOrder.TITLE)

    // Data from Repository
    val allSongs: StateFlow<List<Song>> = repository.songs
    val isScanning: StateFlow<Boolean> = repository.isScanning
    val albums: StateFlow<List<Album>> = repository.albums.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val artists: StateFlow<List<Artist>> = repository.artists.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val folders: StateFlow<List<MusicFolder>> = repository.folders.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val playlists: StateFlow<List<PlaylistEntity>> = repository.allPlaylists.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val favoriteSongs: StateFlow<List<Song>> = repository.favoriteSongs.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val recentlyPlayed: StateFlow<List<Song>> = repository.recentlyPlayedSongs.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val favoriteIds: StateFlow<Set<Long>> = repository.favoriteSongIds
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptySet())

    // Filtered and Sorted Songs
    val filteredSongs: StateFlow<List<Song>> = combine(
        allSongs,
        searchQuery,
        sortOrder
    ) { songs, query, sort ->
        val filtered = if (query.isBlank()) {
            songs
        } else {
            val q = query.trim().lowercase()
            songs.filter {
                it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q)
            }
        }

        when (sort) {
            SortOrder.TITLE -> filtered.sortedBy { it.title.lowercase() }
            SortOrder.ARTIST -> filtered.sortedBy { it.artist.lowercase() }
            SortOrder.DURATION -> filtered.sortedByDescending { it.durationMs }
            SortOrder.DATE_ADDED -> filtered.sortedByDescending { it.dateAdded }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Playback state from Controller
    val currentSong: StateFlow<Song?> = playbackController.currentSong
    val isPlaying: StateFlow<Boolean> = playbackController.isPlaying
    val currentPositionMs: StateFlow<Long> = playbackController.currentPositionMs
    val durationMs: StateFlow<Long> = playbackController.durationMs
    val repeatMode: StateFlow<Int> = playbackController.repeatMode
    val shuffleEnabled: StateFlow<Boolean> = playbackController.shuffleEnabled
    val queue: StateFlow<List<Song>> = playbackController.queue
    val currentIndex: StateFlow<Int> = playbackController.currentIndex

    // Sleep Timer
    private var sleepTimerJob: Job? = null
    private val _sleepTimerMinutesRemaining = MutableStateFlow<Int?>(null)
    val sleepTimerMinutesRemaining: StateFlow<Int?> = _sleepTimerMinutesRemaining.asStateFlow()

    // Add to playlist sheet state
    private val _songPendingPlaylist = MutableStateFlow<Song?>(null)
    val songPendingPlaylist: StateFlow<Song?> = _songPendingPlaylist.asStateFlow()

    fun setPermissionGranted(granted: Boolean) {
        _hasStoragePermission.value = granted
        if (granted) {
            scanSongs()
        }
    }

    fun setSelectedTab(index: Int) {
        _selectedTab.value = index
    }

    fun setSongsSubTab(index: Int) {
        _songsSubTab.value = index
    }

    fun setPlayerSheetExpanded(expanded: Boolean) {
        _isPlayerSheetExpanded.value = expanded
    }

    fun scanSongs() {
        viewModelScope.launch {
            repository.refreshMusicLibrary()
        }
    }

    // Playback Actions
    fun playSong(song: Song, customQueue: List<Song>? = null) {
        val q = customQueue ?: filteredSongs.value.ifEmpty { allSongs.value }
        playbackController.playSong(song, q)
    }

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        playbackController.playQueue(songs, startIndex)
    }

    fun shuffleAll() {
        val songs = allSongs.value.shuffled()
        if (songs.isNotEmpty()) {
            playbackController.playQueue(songs, 0)
        }
    }

    fun playOrPause() {
        playbackController.playOrPause()
    }

    fun skipToNext() {
        playbackController.skipToNext()
    }

    fun skipToPrevious() {
        playbackController.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        playbackController.seekTo(positionMs)
    }

    fun seekBy(deltaMs: Long) {
        playbackController.seekBy(deltaMs)
    }

    fun toggleShuffle() {
        playbackController.toggleShuffle()
    }

    fun cycleRepeatMode() {
        playbackController.cycleRepeatMode()
    }

    fun addToQueue(song: Song) {
        playbackController.addToQueue(song)
    }

    fun removeFromQueue(index: Int) {
        playbackController.removeFromQueue(index)
    }

    // Favorites
    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            val isFav = favoriteIds.value.contains(song.id)
            repository.toggleFavorite(song.id, isFav)
        }
    }

    // Playlists
    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name)
        }
    }

    fun renamePlaylist(id: Long, newName: String) {
        viewModelScope.launch {
            repository.renamePlaylist(id, newName)
        }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(id)
        }
    }

    fun openAddToPlaylist(song: Song) {
        _songPendingPlaylist.value = song
    }

    fun closeAddToPlaylist() {
        _songPendingPlaylist.value = null
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.addSongToPlaylist(playlistId, songId)
            closeAddToPlaylist()
        }
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.removeSongFromPlaylist(playlistId, songId)
        }
    }

    fun getSongsForPlaylist(playlistId: Long): StateFlow<List<Song>> {
        return repository.getSongsForPlaylist(playlistId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    // Sleep Timer
    fun setSleepTimer(minutes: Int?) {
        sleepTimerJob?.cancel()
        _sleepTimerMinutesRemaining.value = minutes

        if (minutes != null && minutes > 0) {
            sleepTimerJob = viewModelScope.launch {
                var remaining = minutes
                while (isActive && remaining > 0) {
                    delay(60_000L)
                    remaining--
                    _sleepTimerMinutesRemaining.value = remaining
                }
                if (isActive) {
                    playbackController.pause()
                    _sleepTimerMinutesRemaining.value = null
                }
            }
        }
    }

    override fun onCleared() {
        playbackController.release()
        sleepTimerJob?.cancel()
        super.onCleared()
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = DarkWaveDatabase.getInstance(application)
                    val scanner = MediaStoreScanner(application)
                    val repository = MusicRepository(scanner, db)
                    val controller = DarkWavePlaybackController(
                        context = application,
                        scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main),
                        onSongPlayed = { song ->
                            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                                repository.recordRecentlyPlayed(song.id)
                            }
                        }
                    )
                    return MusicPlayerViewModel(application, repository, controller) as T
                }
            }
    }
}
