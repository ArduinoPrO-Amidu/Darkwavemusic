package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.db.DarkWaveDatabase
import com.example.data.local.db.FavoriteSongEntity
import com.example.data.local.db.MusicDao
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: DarkWaveDatabase
    private lateinit var musicDao: MusicDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, DarkWaveDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        musicDao = db.musicDao()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DarkWave Music", appName)
    }

    @Test
    fun `store and remove favorite song IDs in Room database`() = runBlocking {
        val songId = 42L

        // Verify initial state is not favorited
        val initialFavs = musicDao.getAllFavoriteSongIds().first()
        assertFalse(initialFavs.contains(songId))

        // Add to favorites
        musicDao.addFavorite(FavoriteSongEntity(songId = songId))

        val updatedFavs = musicDao.getAllFavoriteSongIds().first()
        assertTrue(updatedFavs.contains(songId))
        assertEquals(1, updatedFavs.size)

        // Remove from favorites
        musicDao.removeFavorite(songId)

        val emptyFavs = musicDao.getAllFavoriteSongIds().first()
        assertFalse(emptyFavs.contains(songId))
        assertEquals(0, emptyFavs.size)
    }
}
